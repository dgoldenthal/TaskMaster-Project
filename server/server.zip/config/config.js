module.exports = {
  development: {
    username: "dgold",
    password: "Qazwsx!@12",
    database: "taskmaster",
    host: "127.0.0.1",
    dialect: "postgres",
  },
  test: {
    username: "dgold",
    password: "Qazwsx!@12",
    database: "taskmaster_test",
    host: "127.0.0.1",
    dialect: "postgres",
  },
  production: {
    username: "dgold",
    password: "Qazwsx!@12",
    database: "taskmaster_prod",
    host: "127.0.0.1",
    dialect: "postgres",
  },
};
