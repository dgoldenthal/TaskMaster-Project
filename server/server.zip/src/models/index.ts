// src/models/index.ts
import { Sequelize, DataTypes } from 'sequelize';
import { sequelize } from '../config/database';

export const Project = sequelize.define('Project', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false
  },
  description: {
    type: DataTypes.TEXT
  },
  status: {
    type: DataTypes.ENUM('planning', 'active', 'completed', 'on-hold'),
    defaultValue: 'planning'
  },
  startDate: {
    type: DataTypes.DATE
  },
  dueDate: {
    type: DataTypes.DATE
  },
  ownerId: {
    type: DataTypes.INTEGER,
    allowNull: false
  }
});

export { sequelize };