// server/src/config/db.config.ts
import { Sequelize } from 'sequelize';
import config from './env.config';

export const sequelize = new Sequelize(
  config.database.url,
  config.database.options
);

export const connectDB = async () => {
  try {
    await sequelize.authenticate();
    console.log('Database connection established successfully.');

    if (config.server.isDevelopment) {
      // Sync models in development
      await sequelize.sync({ alter: true });
      console.log('Database models synchronized.');
    }
  } catch (error) {
    console.error('Unable to connect to the database:', error);
    process.exit(1);
  }
};

export default { sequelize, connectDB };