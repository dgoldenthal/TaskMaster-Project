// server/src/config/env.config.ts
import dotenv from 'dotenv';
import { cleanEnv, str, port, url, bool } from 'envalid';

// Load environment variables from .env file
dotenv.config();

const env = cleanEnv(process.env, {
  // Server configuration
  NODE_ENV: str({ choices: ['development', 'test', 'production'] }),
  PORT: port({ default: 5000 }),
  
  // Database configuration
  DATABASE_URL: url(),
  DB_HOST: str({ default: 'localhost' }),
  DB_PORT: port({ default: 5432 }),
  DB_NAME: str(),
  DB_USER: str(),
  DB_PASSWORD: str(),
  
  // JWT configuration
  JWT_SECRET: str(),
  JWT_EXPIRES_IN: str({ default: '24h' }),
  
  // GitHub integration
  GITHUB_CLIENT_ID: str(),
  GITHUB_CLIENT_SECRET: str(),
  GITHUB_WEBHOOK_SECRET: str(),
  
  // Slack integration
  SLACK_CLIENT_ID: str(),
  SLACK_CLIENT_SECRET: str(),
  SLACK_SIGNING_SECRET: str(),
  SLACK_BOT_TOKEN: str({ optional: true }),
  
  // CORS configuration
  CORS_ORIGIN: str({ default: 'http://localhost:3000' }),
  
  // Optional configurations
  ENABLE_LOGGING: bool({ default: true }),
  LOG_LEVEL: str({ choices: ['error', 'warn', 'info', 'debug'], default: 'info' })
});

export const config = {
  server: {
    port: env.PORT,
    nodeEnv: env.NODE_ENV,
    isDevelopment: env.NODE_ENV === 'development',
    isProduction: env.NODE_ENV === 'production',
    corsOrigin: env.CORS_ORIGIN
  },
  
  database: {
    url: env.DATABASE_URL,
    host: env.DB_HOST,
    port: env.DB_PORT,
    name: env.DB_NAME,
    user: env.DB_USER,
    password: env.DB_PASSWORD,
    
    options: {
      dialect: 'postgres' as const,
      logging: env.ENABLE_LOGGING ? console.log : false,
      dialectOptions: env.isProduction ? {
        ssl: {
          require: true,
          rejectUnauthorized: false
        }
      } : {}
    }
  },
  
  jwt: {
    secret: env.JWT_SECRET,
    expiresIn: env.JWT_EXPIRES_IN
  },
  
  github: {
    clientId: env.GITHUB_CLIENT_ID,
    clientSecret: env.GITHUB_CLIENT_SECRET,
    webhookSecret: env.GITHUB_WEBHOOK_SECRET
  },
  
  slack: {
    clientId: env.SLACK_CLIENT_ID,
    clientSecret: env.SLACK_CLIENT_SECRET,
    signingSecret: env.SLACK_SIGNING_SECRET,
    botToken: env.SLACK_BOT_TOKEN
  },
  
  logging: {
    enabled: env.ENABLE_LOGGING,
    level: env.LOG_LEVEL
  }
};

export default config;