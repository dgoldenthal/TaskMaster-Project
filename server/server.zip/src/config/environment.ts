// src/config/environment.ts
interface Environment {
  apiUrl: string;
  wsUrl: string;
  env: string;
  githubClientId: string;
  slackClientId: string;
  sentryDsn?: string;
}

const development: Environment = {
  apiUrl: 'http://localhost:5000/api',
  wsUrl: 'http://localhost:5000',
  env: 'development',
  githubClientId: process.env.REACT_APP_GITHUB_CLIENT_ID!,
  slackClientId: process.env.REACT_APP_SLACK_CLIENT_ID!
};

const production: Environment = {
  apiUrl: process.env.REACT_APP_API_URL!,
  wsUrl: process.env.REACT_APP_WS_URL!,
  env: 'production',
  githubClientId: process.env.REACT_APP_GITHUB_CLIENT_ID!,
  slackClientId: process.env.REACT_APP_SLACK_CLIENT_ID!,
  sentryDsn: process.env.REACT_APP_SENTRY_DSN
};

const env = process.env.NODE_ENV === 'production' ? production : development;

export default env;

// src/config/api.config.ts
import env from './environment';
import axios from 'axios';

export const apiConfig = {
  baseURL: env.apiUrl,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json'
  }
};

// Frontend .env configuration
// .env.development
REACT_APP_API_URL=http://localhost:5000/api
REACT_APP_WS_URL=http://localhost:5000
REACT_APP_GITHUB_CLIENT_ID=your_github_client_id
REACT_APP_SLACK_CLIENT_ID=your_slack_client_id

// .env.production
REACT_APP_API_URL=https://api.taskmaster.com
REACT_APP_WS_URL=wss://api.taskmaster.com
REACT_APP_GITHUB_CLIENT_ID=your_github_client_id
REACT_APP_SLACK_CLIENT_ID=your_slack_client_id
REACT_APP_SENTRY_DSN=your_sentry_dsn

// Backend .env configuration
// .env
NODE_ENV=development
PORT=5000
DATABASE_URL=postgres://postgres:password@localhost:5432/taskmaster
JWT_SECRET=your_jwt_secret
GITHUB_CLIENT_ID=your_github_client_id
GITHUB_CLIENT_SECRET=your_github_client_secret
SLACK_CLIENT_ID=your_slack_client_id
SLACK_CLIENT_SECRET=your_slack_client_secret
SLACK_SIGNING_SECRET=your_slack_signing_secret