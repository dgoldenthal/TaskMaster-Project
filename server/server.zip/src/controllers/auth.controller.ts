// src/controllers/auth.controller.ts
import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { QueryTypes } from 'sequelize';
import { sequelize } from '../config/database';

interface User {
  id: number;
  username: string;
  email: string;
  role: string;
  password: string;
}

interface NewUser {
  id: number;
  username: string;
  email: string;
  role: string;
}

export const login = async (req: Request, res: Response): Promise<void> => {
  try {
    const { email, password } = req.body;
    console.log('Login attempt for email:', email);

    const [user] = await sequelize.query<User>(`
      SELECT id, username, email, password, role 
      FROM users 
      WHERE email = :email
    `, {
      replacements: { email },
      type: QueryTypes.SELECT
    });

    if (!user) {
      res.status(401).json({ message: 'Invalid credentials' });
      return;
    }

    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      res.status(401).json({ message: 'Invalid credentials' });
      return;
    }

    const userId = Number(user.id);
    console.log('User ID for token:', userId);

    const token = jwt.sign(
      { 
        id: userId,
        email: user.email,
        role: user.role
      },
      process.env.JWT_SECRET!,
      { expiresIn: '24h' }
    );

    res.json({
      token,
      user: {
        id: userId,
        email: user.email,
        username: user.username,
        role: user.role
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Server error during login' });
  }
};

export const register = async (req: Request, res: Response): Promise<void> => {
  try {
    const { username, email, password } = req.body;

    const [existingUser] = await sequelize.query(`
      SELECT * FROM users WHERE email = :email OR username = :username
    `, {
      replacements: { email, username },
      type: QueryTypes.SELECT
    });

    if (existingUser) {
      res.status(400).json({ message: 'User already exists' });
      return;
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const [newUser] = await sequelize.query<NewUser>(`
      INSERT INTO users (username, email, password, role, created_at, updated_at)
      VALUES (:username, :email, :password, 'user', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
      RETURNING id, username, email, role;
    `, {
      replacements: { 
        username, 
        email, 
        password: hashedPassword 
      },
      type: QueryTypes.SELECT
    });

    if (!newUser) {
      throw new Error('Failed to create user');
    }

    const token = jwt.sign(
      { id: newUser.id, email, role: 'user' },
      process.env.JWT_SECRET!,
      { expiresIn: '24h' }
    );

    res.status(201).json({
      token,
      user: {
        id: newUser.id,
        username,
        email,
        role: 'user'
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ message: 'Server error during registration' });
  }
};