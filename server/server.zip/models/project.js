// models/Project.js
module.exports = (sequelize, DataTypes) => {
    const Project = sequelize.define('Project', {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true,
        },
        name: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        description: {
            type: DataTypes.TEXT,
        },
        ownerId: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
    }, {
        tableName: 'projects',
        timestamps: true,
    });

    return Project;
};
