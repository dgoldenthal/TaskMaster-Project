const Sequelize = require('sequelize');
const sequelize = require('../config/db.config'); // Import the initialized sequelize instance

const db = {};

// Import Models
db.User = require('./User')(sequelize, Sequelize.DataTypes);
db.Project = require('./Project')(sequelize, Sequelize.DataTypes);
db.Task = require('./Task')(sequelize, Sequelize.DataTypes);

// Define Model Associations (Example)
db.Project.hasMany(db.Task, { foreignKey: 'projectId' });
db.Task.belongsTo(db.Project, { foreignKey: 'projectId' });

db.sequelize = sequelize;
db.Sequelize = Sequelize;

module.exports = db;
