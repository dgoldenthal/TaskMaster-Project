
-- Insert Projects
INSERT INTO projects (name, description, ownerId, createdAt, updatedAt) VALUES
('Project Alpha', 'This is the first test project', 1, NOW(), NOW()),
('Project Beta', 'This is the second test project', 2, NOW(), NOW()),
('Project Gamma', 'This is the third test project', 3, NOW(), NOW());

-- Insert Tasks
INSERT INTO tasks (title, description, projectId, assignedTo, createdAt, updatedAt) VALUES
('Task 1', 'Complete project setup', 1, 2, NOW(), NOW()),
('Task 2', 'Implement user authentication', 1, 3, NOW(), NOW()),
('Task 3', 'Design project dashboard', 2, 1, NOW(), NOW()),
('Task 4', 'Add real-time notifications', 2, 2, NOW(), NOW()),
('Task 5', 'Write project documentation', 3, 3, NOW(), NOW());
