A full-stack project management application built with React, Node.js, Express, and PostgreSQL.

## Technologies Used

- Frontend: React, Redux Toolkit, Tailwind CSS
- Backend: Node.js, Express.js
- Database: PostgreSQL with Sequelize ORM
- Authentication: JWT

## Getting Started

Instructions for setting up and running the project locally..." > README.md