import React from 'react';

const Reports: React.FC = () => {
  return (
    <div>
      <h1>Reports</h1>
      <p>This is the Reports page.</p>
    </div>
  );
};

export default Reports;
