import React from 'react';

const Help: React.FC = () => {
  return (
    <div>
      <h1>Help</h1>
      <p>This is the Help page.</p>
    </div>
  );
};

export default Help;
