import React from 'react';

const Calendar: React.FC = () => {
  return (
    <div>
      <h1>Calendar</h1>
      <p>This is the Calendar page.</p>
    </div>
  );
};

export default Calendar;
