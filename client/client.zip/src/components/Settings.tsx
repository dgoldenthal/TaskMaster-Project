import React from 'react';

const Settings: React.FC = () => {
  return (
    <div>
      <h1>Settings</h1>
      <p>This is the Settings page.</p>
    </div>
  );
};

export default Settings;
