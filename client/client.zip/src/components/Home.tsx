import React from 'react';

const Home: React.FC = () => {
  return (
    <div>
      <h1>Welcome to TaskMaster Pro</h1>
      <p>Manage your projects efficiently with TaskMaster Pro.</p>
    </div>
  );
};

export default Home;
