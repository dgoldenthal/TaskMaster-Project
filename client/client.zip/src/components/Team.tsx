import React from 'react';

const Team: React.FC = () => {
  return (
    <div>
      <h1>team</h1>
      <p>This is the Team page.</p>
    </div>
  );
};

export default Team;
